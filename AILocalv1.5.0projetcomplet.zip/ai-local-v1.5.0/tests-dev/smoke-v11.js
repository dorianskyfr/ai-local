// Smoke test : charge le vrai renderer dans Chromium headless et vérifie
// le pipeline de réponse de bout en bout (calcul %, apprentissage, rappel,
// question de suivi) — sans réseau, comme un PC hors ligne.
const { chromium } = require('playwright-core');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });

  await page.goto('file:///home/user/ai-local/renderer/index.html');
  await page.waitForTimeout(1500);

  const send = async (text) => {
    await page.fill('#input', text);
    await page.click('#send-btn');
    // attend la fin du streaming : le nombre de bulles IA se stabilise
    await page.waitForFunction(() => {
      const b = document.querySelectorAll('.message.ai:not(.typing) .bubble');
      const last = b[b.length - 1];
      return last && !document.querySelector(".message.typing") && last.textContent.length > 3;
    }, { timeout: 20000 });
    await page.waitForTimeout(2500); // laisse finir le streaming mot à mot
    return page.evaluate(() => {
      const b = document.querySelectorAll('.message.ai:not(.typing) .bubble');
      return b[b.length - 1].textContent.trim();
    });
  };

  let ok = true;
  const check = (name, cond, detail) => {
    console.log(`${cond ? '✅' : '❌'} ${name}${cond ? '' : ' — ' + detail}`);
    if (!cond) ok = false;
  };

  const panel = await page.evaluate(() => document.getElementById('llm-status').textContent);
  check('panneau LLM : repli propre sans pont Electron', panel.includes('Indisponible'), panel);

  const r1 = await send('combien font 20% de 150 ?');
  check('calcul de pourcentage', r1.includes('= 30'), r1);

  // On enseigne des faits directement au cerveau (comme un entraînement),
  // puis on vérifie rappel + composition + suivi.
  await page.evaluate(() => {
    brain.learn("Le Kilimandjaro est un volcan endormi situé au nord-est de la Tanzanie, près de la frontière kényane.", 1, 'Kilimandjaro');
    brain.learn("Le point culminant du Kilimandjaro atteint une altitude de 5895 mètres, ce qui en fait le plus haut sommet d'Afrique.", 1, 'Kilimandjaro');
  });
  const r2 = await send('parle-moi du Kilimandjaro');
  check('rappel multi-faits avec source', r2.includes('Kilimandjaro') && (r2.includes('Tanzanie') || r2.includes('5895')), r2);

  const r3 = await send('et son altitude ?');
  check('question de suivi (contexte)', r3.includes('5895'), r3);

  const r4 = await send('parle-moi de Zorglubville');
  check('sujet inconnu → aveu honnête (hors ligne)', /ne (connais|sais)|ne me dit rien|pas encore/i.test(r4), r4);

  const realErrors = errors.filter(e => !/net::|Failed to fetch|ERR_|discord/i.test(e));
  check('aucune erreur JS au chargement/usage', realErrors.length === 0, realErrors.join(' | '));

  await page.screenshot({ path: '/tmp/claude-0/-home-user-ai-local/05f4a966-0ed3-5027-86ae-df87e391fd29/scratchpad/smoke-v11.png', fullPage: false });
  await browser.close();
  process.exit(ok ? 0 : 1);
})();
