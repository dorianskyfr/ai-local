// Grande suite de bout en bout v1.5 : toute l'app dans Chromium headless,
// hors ligne (comme un PC sans internet) — chaque vue et chaque flux principal.
const { chromium } = require('playwright-core');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });

  await page.goto('file:///home/user/ai-local/renderer/index.html');
  await page.waitForTimeout(1500);

  const send = async (text, waitMs = 2500) => {
    await page.fill('#input', text);
    await page.click('#send-btn');
    await page.waitForFunction(() => {
      const b = document.querySelectorAll('.message.ai:not(.typing) .bubble');
      const last = b[b.length - 1];
      return last && !document.querySelector('.message.typing') && last.textContent.length > 3;
    }, { timeout: 25000 });
    await page.waitForTimeout(waitMs);
    return page.evaluate(() => {
      const b = document.querySelectorAll('.message.ai:not(.typing) .bubble');
      return b[b.length - 1].textContent.trim();
    });
  };

  let ok = true;
  const check = (name, cond, detail) => {
    console.log(`${cond ? '✅' : '❌'} ${name}${cond ? '' : ' — ' + detail}`);
    if (!cond) ok = false;
  };

  // --- Panneau LLM (pas de pont Electron dans ce test → repli propre) ---
  const panel = await page.evaluate(() => document.getElementById('llm-status').textContent);
  check('panneau LLM : repli propre sans pont Electron', panel.includes('Indisponible'), panel);

  // --- Badge de version : reste cohérent (statique hors Electron) ---
  const badge = await page.evaluate(() => document.querySelector('.version-badge').textContent);
  check('badge de version affiché', /^v\d+\.\d+$/.test(badge), badge);

  // --- Outils exacts ---
  const r1 = await send('combien font 20% de 150 ?');
  check('calcul de pourcentage', r1.includes('= 30'), r1);
  const r2 = await send('combien font (12 + 8) x 3 ?');
  check('calcul avec parenthèses', r2.includes('= 60'), r2);

  // --- Mémoire de faits : rappel, multi-faits, suivi ---
  await page.evaluate(() => {
    brain.learn("Le Kilimandjaro est un volcan endormi situé au nord-est de la Tanzanie, près de la frontière kényane.", 1, 'Kilimandjaro');
    brain.learn("Le point culminant du Kilimandjaro atteint une altitude de 5895 mètres, ce qui en fait le plus haut sommet d'Afrique.", 1, 'Kilimandjaro');
  });
  const r3 = await send('parle-moi du Kilimandjaro');
  check('rappel multi-faits avec source', r3.includes('Kilimandjaro') && (r3.includes('Tanzanie') || r3.includes('5895')), r3);
  const r4 = await send('et son altitude ?');
  check('question de suivi (contexte)', r4.includes('5895'), r4);
  const r5 = await send('parle-moi de Zorglubville');
  check('sujet inconnu → aveu honnête (hors ligne)', /ne (connais|sais)|ne me dit rien|pas encore/i.test(r5), r5);

  // --- Anti-réentrance : Entrée pendant une réponse ne double pas l'envoi ---
  await page.fill('#input', 'test réentrance');
  await page.evaluate(() => {
    document.getElementById('send-btn').disabled = true;
    handleSend();
    document.getElementById('send-btn').disabled = false;
  });
  const userCountAfter = await page.evaluate(() =>
    document.querySelectorAll('.message.user').length);
  const typingCount = await page.evaluate(() => document.querySelectorAll('.message.typing').length);
  check('garde anti-réentrance active', typingCount === 0, `typing=${typingCount}`);

  // --- Conversations : création, bascule, contexte remis à zéro ---
  await page.click('#new-chat-btn');
  await page.waitForTimeout(300);
  const emptyChat = await page.evaluate(() => document.querySelectorAll('.message').length);
  check('nouvelle conversation vide', emptyChat === 0, String(emptyChat));
  const topicReset = await page.evaluate(() => brain.lastTopic.length === 0);
  check('sujet de suivi remis à zéro en changeant de conversation', topicReset, '');
  const r6 = await send('et son altitude ?');
  check('pas de fuite de contexte dans la nouvelle conversation', !r6.includes('5895'), r6);

  const convCount = await page.evaluate(() => document.querySelectorAll('.conversation-item').length);
  check('les deux conversations listées', convCount >= 2, String(convCount));
  await page.evaluate(() => document.querySelectorAll('.conversation-item')[1].click());
  await page.waitForTimeout(300);
  const restored = await page.evaluate(() =>
    [...document.querySelectorAll('.message .bubble')].some(b => b.textContent.includes('Kilimandjaro')));
  check('bascule vers l\'ancienne conversation restaurée', restored, '');

  // --- Génération d'image dans le chat + galerie ---
  await page.fill('#input', 'dessine un volcan');
  await page.click('#send-btn');
  await page.waitForSelector('.message.ai img', { timeout: 20000 });
  const imgOk = await page.evaluate(() => {
    const img = document.querySelector('.message.ai img');
    return img && img.src.startsWith('data:image') && img.src.length > 1000;
  });
  check('image générée dans le chat (hors ligne)', imgOk, '');
  await page.click('#tab-gallery');
  await page.waitForTimeout(300);
  const galleryCount = await page.evaluate(() => document.querySelectorAll('.gallery-card').length);
  check('image conservée dans la galerie', galleryCount >= 1, String(galleryCount));

  // --- Onglet entraînement : démarrage/arrêt hors ligne + vitesse personnalisée ---
  await page.click('#tab-training');
  await page.waitForTimeout(200);
  await page.selectOption('#train-speed', 'custom');
  await page.waitForTimeout(400);
  const customNote = await page.evaluate(() => {
    const el = document.getElementById('custom-speed-note');
    return el.hidden ? '' : el.textContent;
  });
  check('vitesse personnalisée : cadence + préréglage équivalent affichés', /Cadence.*équivalent ≈/.test(customNote), customNote);

  await page.click('#train-start');
  await page.waitForTimeout(2500);
  const feedHasEntries = await page.evaluate(() =>
    document.querySelectorAll('#train-feed .log-entry').length >= 2);
  check('entraînement hors ligne : cycles locaux + journal alimenté', feedHasEntries, '');
  const statsLive = await page.evaluate(() =>
    parseInt(document.getElementById('stat-epochs').textContent, 10) >= 1);
  check('statistiques mises à jour (cycles ≥ 1)', statsLive, '');
  await page.click('#train-start');
  await page.waitForTimeout(300);
  const stopped = await page.evaluate(() =>
    [...document.querySelectorAll('#train-feed .log-entry')].some(e => e.textContent.includes('arrêté')));
  check('arrêt propre de l\'entraînement', stopped, '');

  // --- Paliers + échelle honnête ---
  const scaleNote = await page.evaluate(() => document.getElementById('scale-note').textContent);
  check('échelle honnête affichée (pas de fausse équivalence)', scaleNote.includes('pas une équivalence'), scaleNote);

  // --- Persistance : le modèle survit à un rechargement ---
  await page.reload();
  await page.waitForTimeout(1500);
  const persisted = await page.evaluate(() => brain.recall('altitude du Kilimandjaro'));
  check('mémoire persistée après rechargement', !!(persisted && persisted.text.includes('5895')), JSON.stringify(persisted));

  // --- Zéro erreur JS sur tout le parcours ---
  const realErrors = errors.filter(e => !/net::|Failed to fetch|ERR_|discord/i.test(e));
  check('aucune erreur JS sur tout le parcours', realErrors.length === 0, realErrors.slice(0, 3).join(' | '));

  await page.screenshot({ path: '/tmp/claude-0/-home-user-ai-local/05f4a966-0ed3-5027-86ae-df87e391fd29/scratchpad/smoke-v15.png' });
  await browser.close();
  console.log(ok ? '\nTOUT EST VERT' : '\nÉCHECS PRÉSENTS');
  process.exit(ok ? 0 : 1);
})();
