// Tests du moteur v1.1 — exécutés avec Node sur le vrai renderer/brain.js
const fs = require('fs');
const path = require('path');

global.window = {};
eval(fs.readFileSync(path.join('/home/user/ai-local/renderer/brain.js'), 'utf8'));
const Brain = global.window.Brain;

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log(`  ✅ ${name}`); }
  catch (e) { failed++; console.log(`  ❌ ${name}\n     ${e.message}`); }
}
function assert(cond, msg) { if (!cond) throw new Error(msg); }

function freshBrain() {
  const b = new Brain();
  // Corpus de faits variés avec sources (aucun nom réel de l'utilisateur)
  b.learn("Le Kilimandjaro est un volcan endormi situé au nord-est de la Tanzanie, près de la frontière kényane.", 1, 'Kilimandjaro');
  b.learn("Le point culminant du Kilimandjaro atteint une altitude de 5895 mètres, ce qui en fait le plus haut sommet d'Afrique.", 1, 'Kilimandjaro');
  b.learn("La dernière éruption majeure du Kilimandjaro remonte à environ 360000 ans selon les géologues actuels.", 1, 'Kilimandjaro');
  b.learn("Un volcan est une structure géologique qui résulte de la montée d'un magma puis de son éruption en surface.", 1, 'Volcan');
  b.learn("La photosynthèse est le processus par lequel les plantes convertissent la lumière du soleil en énergie chimique.", 1, 'Photosynthèse');
  b.learn("En 2022, la commune de Roquebrune comptait 1450 habitants selon le dernier recensement officiel publié.", 1, 'Roquebrune');
  b.learn("La bataille de Marignan a eu lieu en 1515 près de Milan et opposa François Premier aux Suisses.", 1, 'Bataille de Marignan');
  b.learn("Le pays d'élection était une circonscription fiscale de l'Ancien Régime où les impôts étaient répartis par des élus.", 1, "Pays d'élection");
  return b;
}

console.log('\n— Rappel pondéré par rareté —');
test('question précise → bon fait cité avec sa source', () => {
  const b = freshBrain();
  const top = b.recallTop('quelle est la hauteur du Kilimandjaro ?', 1);
  assert(top.length === 1, 'aucun résultat');
  assert(top[0].m.text.includes('5895'), `mauvais fait : ${top[0].m.text}`);
});
test('question de quantité favorise les phrases chiffrées', () => {
  const b = freshBrain();
  const top = b.recallTop('combien d\'habitants à Roquebrune ?', 1);
  assert(top.length && top[0].m.text.includes('1450'), `mauvais fait : ${top.length ? top[0].m.text : 'aucun'}`);
});
test('question de date favorise les phrases avec année', () => {
  const b = freshBrain();
  const top = b.recallTop('en quelle année a eu lieu la bataille de Marignan ?', 1);
  assert(top.length && top[0].m.text.includes('1515'), `mauvais fait : ${top.length ? top[0].m.text : 'aucun'}`);
});
test('définition : « c\'est quoi X » préfère la phrase « X est … »', () => {
  const b = freshBrain();
  const top = b.recallTop('c\'est quoi un volcan ?', 1);
  assert(top.length && /^Un volcan est/.test(top[0].m.text), `mauvais fait : ${top.length ? top[0].m.text : 'aucun'}`);
});

console.log('\n— Honnêteté (anti-hallucination, régressions v0.8/v0.9) —');
test('sujet jamais appris → aucune citation', () => {
  const b = freshBrain();
  assert(b.recallTop('combien d\'habitants à Trifouillis ?', 1).length === 0, 'a cité un fait pour un sujet inconnu');
});
test('mots génériques seuls ne raccrochent pas un souvenir hors sujet', () => {
  const b = freshBrain();
  const top = b.recallTop('le nombre d\'habitants du village de Zorglubville', 1);
  assert(top.length === 0, `a cité : ${top.length ? top[0].m.text : ''}`);
});
test('reply() admet son ignorance et lève lastUnknown', () => {
  const b = freshBrain();
  b.reply('parle-moi de Zorglubville');
  assert(b.lastUnknown === true, 'lastUnknown non levé');
});

console.log('\n— Tolérance aux fautes de frappe —');
test('une lettre erronée dans le sujet est corrigée', () => {
  const b = freshBrain();
  const top = b.recallTop('quelle est la hauteur du Kilimandjaru ?', 1);
  assert(top.length && top[0].m.text.includes('5895'), `pas corrigé : ${top.length ? top[0].m.text : 'aucun'}`);
});
test('un mot trop éloigné n\'est PAS corrigé (pas de faux positif)', () => {
  const b = freshBrain();
  assert(b.recallTop('quelle est la hauteur du Kirimandjaru ?', 1).length === 0 ||
         !Brain.withinOneEdit('kirimandjaru', 'kilimandjaro'), 'correction trop laxiste');
});
test('withinOneEdit : substitution/insertion/suppression OK, 2 fautes KO', () => {
  assert(Brain.withinOneEdit('volcan', 'vulcan'), 'substitution ratée');
  assert(Brain.withinOneEdit('volcan', 'volcans'), 'insertion ratée');
  assert(Brain.withinOneEdit('volcan', 'volan'), 'suppression ratée');
  assert(!Brain.withinOneEdit('volcan', 'vulkan'), '2 substitutions acceptées');
});

console.log('\n— Contexte de conversation (questions de suivi) —');
test('« et sa hauteur ? » hérite du sujet précédent', () => {
  const b = freshBrain();
  b.recallTop('parle-moi du Kilimandjaro', 1); // fixe le sujet
  const top = b.recallTop('et sa hauteur ?', 1, { context: true });
  assert(top.length && top[0].m.text.includes('5895'), `suivi raté : ${top.length ? top[0].m.text : 'aucun'}`);
});
test('reply() enchaîne deux questions sur le même sujet', () => {
  const b = freshBrain();
  b.reply('parle-moi du Kilimandjaro');
  const r = b.reply('et sa dernière éruption ?');
  assert(r.includes('360000') || r.includes('éruption'), `suivi raté : ${r}`);
});

console.log('\n— Réponses composées (multi-faits) —');
test('answerFromMemory combine des faits complémentaires du même sujet', () => {
  const b = freshBrain();
  const a = b.answerFromMemory('parle-moi du Kilimandjaro');
  assert(a, 'aucune réponse');
  assert(a.includes('Tanzanie') || a.includes('5895') || a.includes('volcan endormi'), `réponse : ${a}`);
  const nbFaits = (a.match(/\. [A-ZÉÈL]/g) || []).length + 1;
  assert(a.length > 100, `réponse trop courte pour un multi-faits : ${a}`);
});
test('answerFromMemory cite la source', () => {
  const b = freshBrain();
  const a = b.answerFromMemory('c\'est quoi la photosynthèse ?');
  assert(a && a.includes('Photosynthèse') && a.includes('lumière'), `réponse : ${a}`);
});
test('fait personnel : rappel avec « Tu m\'avais dit »', () => {
  const b = freshBrain();
  b.learn('Mon animal préféré est le renard polaire des montagnes.', 1, 'toi');
  const a = b.answerFromMemory('quel est mon animal préféré ?');
  assert(a && a.startsWith('Tu m\'avais dit'), `réponse : ${a}`);
});

console.log('\n— Outils exacts —');
test('pourcentage : 20 % de 150 = 30', () => {
  const b = new Brain();
  const r = b.mathAnswer('combien font 20% de 150 ?');
  assert(r && r.includes('= 30'), `réponse : ${r}`);
});
test('pourcentage décimal : 12,5 % de 80 = 10', () => {
  const b = new Brain();
  const r = b.mathAnswer('12,5% de 80');
  assert(r && r.includes('= 10'), `réponse : ${r}`);
});
test('arithmétique toujours exacte : (3 + 4) × 5 = 35', () => {
  const b = new Brain();
  const r = b.mathAnswer('combien font (3 + 4) x 5 ?');
  assert(r && r.includes('= 35'), `réponse : ${r}`);
});
test('le modulo arithmétique marche toujours : 17 % 5 = 2', () => {
  const b = new Brain();
  const r = b.mathAnswer('17 % 5');
  assert(r && r.includes('= 2'), `réponse : ${r}`);
});

console.log('\n— Comportements conservés —');
test('salutation → petite conversation, pas de recherche', () => {
  const b = freshBrain();
  const r = b.reply('salut');
  assert(!b.lastUnknown && r.length > 5, `réponse : ${r}`);
});
test('confidence personnelle → accusé de réception + mémorisation', () => {
  const b = freshBrain();
  const r = b.reply('mon chien s\'appelle Caramel et il adore courir dans le jardin');
  assert(!b.lastUnknown, 'parti en recherche au lieu d\'accuser réception');
  assert(b.memory.some(m => m.source === 'toi' && m.text.includes('Caramel')), 'pas mémorisé');
});
test('recall() (compat) renvoie toujours le meilleur fait unique', () => {
  const b = freshBrain();
  const f = b.recall('altitude du Kilimandjaro');
  assert(f && f.text.includes('5895'), `fait : ${f ? f.text : 'aucun'}`);
});
test('mergeShared + cap mémoire à 12000', () => {
  const b = new Brain();
  assert(Brain.MEMORY_CAP === 12000, 'cap incorrect');
  const other = freshBrain();
  b.mergeShared(other.exportShared());
  assert(b.recall('altitude du Kilimandjaro'), 'fusion sans rappel');
});

console.log('\n— Performance (index inversé) —');
test('10 000 souvenirs : rappel < 50 ms', () => {
  const b = new Brain();
  for (let i = 0; i < 10000; i++) {
    b.remember(`La commune fictive numéro ${i} possède une mairie, une école et un lavoir restauré en pierre locale du pays.`, `Commune ${i}`);
  }
  b.remember('Le mont Ventoux culmine à 1910 mètres et domine la Provence de sa silhouette pelée caractéristique.', 'Mont Ventoux');
  b.memoryKeywordDf(); // reconstruit l'index (amorti : seulement quand la mémoire change)
  const t0 = Date.now();
  const top = b.recallTop('quelle est l\'altitude du mont Ventoux ?', 1);
  const dt = Date.now() - t0;
  assert(top.length && top[0].m.text.includes('1910'), 'mauvais fait');
  assert(dt < 50, `trop lent : ${dt} ms`);
});

console.log(`\n${passed} réussi(s), ${failed} échec(s)`);
process.exit(failed ? 1 : 0);
