// Tests v1.2 — llm-main.js (électron stubé) + prompting.js
const fs = require('fs');
const os = require('os');
const path = require('path');
const Module = require('module');

let passed = 0, failed = 0;
function test(name, fn) {
  Promise.resolve().then(fn).then(
    () => { passed++; console.log(`  ✅ ${name}`); },
    (e) => { failed++; console.log(`  ❌ ${name}\n     ${e.message}`); }
  );
}
function assert(cond, msg) { if (!cond) throw new Error(msg); }

// --- Stub d'electron pour charger llm-main.js hors app ---
const tmpUserData = fs.mkdtempSync(path.join(os.tmpdir(), 'ailocal-test-'));
const handlers = new Map();
const listeners = new Map();
const origLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === 'electron') {
    return {
      app: { getPath: () => tmpUserData },
      ipcMain: {
        handle: (ch, fn) => handlers.set(ch, fn),
        on: (ch, fn) => listeners.set(ch, fn)
      }
    };
  }
  return origLoad.apply(this, arguments);
};

const llm = require('/home/user/ai-local/llm-main.js');
llm.registerLlmIpc();
const fakeEvent = { sender: { send() {} } };

(async () => {
  console.log('\n— Catalogue de modèles —');
  test('entrées valides : https, .gguf, licence Apache, taille annoncée', () => {
    const ids = Object.keys(llm.CATALOG);
    assert(ids.length >= 3, 'catalogue trop petit');
    for (const id of ids) {
      const m = llm.CATALOG[id];
      assert(/^https:\/\/huggingface\.co\/(Qwen|bartowski)\//.test(m.url), `URL suspecte : ${m.url}`);
      assert(m.url.endsWith(m.file), `URL/fichier incohérents pour ${id}`);
      assert(/\.gguf$/.test(m.file), `pas un .gguf : ${m.file}`);
      assert(m.license === 'Apache 2.0', `licence non redistribuable : ${m.license}`);
      assert(m.approxMo > 100, 'taille manquante');
    }
  });
  test('le prompt système impose français + honnêteté + local', () => {
    assert(/français/i.test(llm.SYSTEM_PROMPT), 'pas de consigne de langue');
    assert(/honnête/i.test(llm.SYSTEM_PROMPT), 'pas de consigne d\'honnêteté');
    assert(/local|machine|ordinateur/i.test(llm.SYSTEM_PROMPT), 'pas d\'identité locale');
  });

  console.log('\n— IPC enregistrés —');
  test('tous les canaux attendus existent', () => {
    for (const ch of ['llm-status', 'llm-download', 'llm-load', 'llm-unload', 'llm-generate']) {
      assert(handlers.has(ch), `handler manquant : ${ch}`);
    }
    for (const ch of ['llm-abort', 'llm-reset-chat', 'llm-download-abort']) {
      assert(listeners.has(ch), `listener manquant : ${ch}`);
    }
  });

  console.log('\n— Comportement sans modèle (le cas de tous les nouveaux utilisateurs) —');
  test('llm-status : rien de téléchargé, pas prêt, catalogue exposé', async () => {
    const s = await handlers.get('llm-status')(fakeEvent);
    assert(s.ready === false, 'ready devrait être false');
    assert(s.models.length >= 3 && s.models.every(m => !m.downloaded), 'downloaded devrait être false partout');
  });
  test('llm-generate sans modèle → erreur propre, pas de crash', async () => {
    const r = await handlers.get('llm-generate')(fakeEvent, { prompt: 'salut' });
    assert(r.ok === false && /modèle/i.test(r.error), `réponse : ${JSON.stringify(r)}`);
  });
  test('llm-load sans fichier → erreur propre', async () => {
    const r = await handlers.get('llm-load')(fakeEvent, { id: 'qwen2.5-1.5b' });
    assert(r.ok === false && /téléchargé/i.test(r.error), `réponse : ${JSON.stringify(r)}`);
  });
  test('llm-download avec URL invalide → erreur propre', async () => {
    const r = await handlers.get('llm-download')(fakeEvent, { id: 'custom', url: 'ftp://pas-bon' });
    assert(r.ok === false && /URL invalide/i.test(r.error), `réponse : ${JSON.stringify(r)}`);
  });
  test('llm-reset-chat et llm-abort sans modèle → silencieux', async () => {
    await listeners.get('llm-reset-chat')();
    listeners.get('llm-abort')();
  });

  console.log('\n— Prompting (RAG) —');
  global.window = {};
  eval(fs.readFileSync('/home/user/ai-local/renderer/prompting.js', 'utf8'));
  const P = global.window.Prompting;
  test('sans fait : la question passe telle quelle', () => {
    assert(P.userPrompt('Bonjour, ça va ?') === 'Bonjour, ça va ?', 'question modifiée');
  });
  test('avec faits : sources numérotées + question à la fin', () => {
    const p = P.userPrompt('quelle hauteur ?', [
      { text: 'Il culmine à 5895 mètres.', source: 'Kilimandjaro' },
      { text: 'Volcan endormi de Tanzanie.', source: 'Kilimandjaro' }
    ]);
    assert(p.includes('1. (source : Kilimandjaro) Il culmine à 5895 mètres.'), p);
    assert(p.includes('2. (source : Kilimandjaro)'), p);
    assert(p.trim().endsWith('Question : quelle hauteur ?'), p);
  });
  test('faits limités à 5 et tronqués proprement', () => {
    const facts = Array.from({ length: 8 }, (_, i) => ({ text: 'x'.repeat(400), source: 'S' + i }));
    const p = P.userPrompt('q ?', facts);
    assert(!p.includes('S5'), 'plus de 5 faits injectés');
    assert(p.includes('…'), 'pas de troncature');
    assert(p.length < 2000, 'prompt démesuré : ' + p.length);
  });

  setTimeout(() => {
    console.log(`\n${passed} réussi(s), ${failed} échec(s)`);
    process.exit(failed ? 1 : 0);
  }, 500);
})();
